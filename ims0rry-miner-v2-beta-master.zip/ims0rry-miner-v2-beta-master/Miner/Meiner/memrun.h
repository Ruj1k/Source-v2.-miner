#pragma once
extern int RunPortableExecutable(void* Image);