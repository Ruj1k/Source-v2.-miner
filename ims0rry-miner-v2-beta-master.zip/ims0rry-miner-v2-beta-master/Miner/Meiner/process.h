#pragma once
#include "stdafx.h"
using namespace std;
DWORD isProcessRun(char *processName);
void killProcess(const char *filename);